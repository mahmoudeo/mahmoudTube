$(document).ready(function () {
    $(".removed").click(function () {
        $(this).parents(".card").hide()
    })
})